﻿'Class: This is the Inventory window that is called when the user clicks Show Inventory in the file menu



Public Class frmInventory
    Private Sub FrmInventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'the frmInventory load event reads the InventoryTextFile and fills the textbox with items

        'intialize an instance of streamreader
        Dim objReader As IO.StreamReader
        Dim strLocationAndNameofFile = "d:\InventoryTextFile.txt"
        Dim intCount As Integer = 0
        Dim strFileError = "InventoryTextFile.txt could not be found. Restart when the file is available."

        'verify InventoryTextFileExists
        If IO.File.Exists(strLocationAndNameofFile) Then
            'open file and write it to txtInventoryDisplay
            objReader = IO.File.OpenText(strLocationAndNameofFile)
            txtInventoryDisplay.Text = objReader.ReadToEnd
            objReader.Close()


        End If



    End Sub

    Private Sub BtnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        'this opens the first form again
        Dim MiniCooper As New frmMiniCooper

        Hide()
        MiniCooper.showDialog()

    End Sub
End Class