﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCoilCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblBattery = New System.Windows.Forms.Label()
        Me.lblCoil = New System.Windows.Forms.Label()
        Me.lblVoltage = New System.Windows.Forms.Label()
        Me.lblSafe = New System.Windows.Forms.Label()
        Me.lblCurrent = New System.Windows.Forms.Label()
        Me.lblWattage = New System.Windows.Forms.Label()
        Me.ToolTipBattery = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtBatteryRating = New System.Windows.Forms.TextBox()
        Me.ToolTipCoil = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtCoilResist = New System.Windows.Forms.TextBox()
        Me.ToolTipVoltage = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtVoltage = New System.Windows.Forms.TextBox()
        Me.BtnCalculate = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Nyet Halftone Italic", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Red
        Me.lblTitle.Location = New System.Drawing.Point(26, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(837, 48)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Quick and Dirty Coil Calculator"
        '
        'lblBattery
        '
        Me.lblBattery.AutoSize = True
        Me.lblBattery.BackColor = System.Drawing.Color.Transparent
        Me.lblBattery.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBattery.ForeColor = System.Drawing.Color.Red
        Me.lblBattery.Location = New System.Drawing.Point(91, 112)
        Me.lblBattery.Name = "lblBattery"
        Me.lblBattery.Size = New System.Drawing.Size(231, 34)
        Me.lblBattery.TabIndex = 1
        Me.lblBattery.Text = "Battery Rating:"
        Me.ToolTipBattery.SetToolTip(Me.lblBattery, "The number of Amps your battery is rated to safely handle.")
        '
        'lblCoil
        '
        Me.lblCoil.AutoSize = True
        Me.lblCoil.BackColor = System.Drawing.Color.Transparent
        Me.lblCoil.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCoil.ForeColor = System.Drawing.Color.Red
        Me.lblCoil.Location = New System.Drawing.Point(85, 229)
        Me.lblCoil.Name = "lblCoil"
        Me.lblCoil.Size = New System.Drawing.Size(237, 34)
        Me.lblCoil.TabIndex = 2
        Me.lblCoil.Text = "Coil Resistance:"
        Me.ToolTipCoil.SetToolTip(Me.lblCoil, "The current resistance of your coil.")
        '
        'lblVoltage
        '
        Me.lblVoltage.AutoSize = True
        Me.lblVoltage.BackColor = System.Drawing.Color.Transparent
        Me.lblVoltage.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoltage.ForeColor = System.Drawing.Color.Red
        Me.lblVoltage.Location = New System.Drawing.Point(76, 169)
        Me.lblVoltage.Name = "lblVoltage"
        Me.lblVoltage.Size = New System.Drawing.Size(246, 34)
        Me.lblVoltage.TabIndex = 3
        Me.lblVoltage.Text = "Battery Voltage:"
        Me.ToolTipVoltage.SetToolTip(Me.lblVoltage, "The peak voltage of your battery. ")
        '
        'lblSafe
        '
        Me.lblSafe.AutoSize = True
        Me.lblSafe.BackColor = System.Drawing.Color.Transparent
        Me.lblSafe.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSafe.ForeColor = System.Drawing.Color.Lime
        Me.lblSafe.Location = New System.Drawing.Point(498, 112)
        Me.lblSafe.Name = "lblSafe"
        Me.lblSafe.Size = New System.Drawing.Size(243, 34)
        Me.lblSafe.TabIndex = 4
        Me.lblSafe.Text = "This Coil is Safe!"
        Me.lblSafe.Visible = False
        '
        'lblCurrent
        '
        Me.lblCurrent.AutoSize = True
        Me.lblCurrent.BackColor = System.Drawing.Color.Transparent
        Me.lblCurrent.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent.ForeColor = System.Drawing.Color.Red
        Me.lblCurrent.Location = New System.Drawing.Point(498, 169)
        Me.lblCurrent.Name = "lblCurrent"
        Me.lblCurrent.Size = New System.Drawing.Size(170, 34)
        Me.lblCurrent.TabIndex = 5
        Me.lblCurrent.Text = "Amperage:"
        Me.lblCurrent.Visible = False
        '
        'lblWattage
        '
        Me.lblWattage.AutoSize = True
        Me.lblWattage.BackColor = System.Drawing.Color.Transparent
        Me.lblWattage.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWattage.ForeColor = System.Drawing.Color.Red
        Me.lblWattage.Location = New System.Drawing.Point(498, 229)
        Me.lblWattage.Name = "lblWattage"
        Me.lblWattage.Size = New System.Drawing.Size(147, 34)
        Me.lblWattage.TabIndex = 6
        Me.lblWattage.Text = "Wattage:"
        Me.lblWattage.Visible = False
        '
        'txtBatteryRating
        '
        Me.txtBatteryRating.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold)
        Me.txtBatteryRating.Location = New System.Drawing.Point(328, 109)
        Me.txtBatteryRating.Name = "txtBatteryRating"
        Me.txtBatteryRating.Size = New System.Drawing.Size(78, 40)
        Me.txtBatteryRating.TabIndex = 7
        Me.txtBatteryRating.Text = "35"
        Me.txtBatteryRating.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCoilResist
        '
        Me.txtCoilResist.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold)
        Me.txtCoilResist.Location = New System.Drawing.Point(328, 229)
        Me.txtCoilResist.Name = "txtCoilResist"
        Me.txtCoilResist.Size = New System.Drawing.Size(78, 40)
        Me.txtCoilResist.TabIndex = 8
        Me.txtCoilResist.Text = ".95"
        Me.txtCoilResist.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtVoltage
        '
        Me.txtVoltage.Font = New System.Drawing.Font("Tahoma", 16.2!, System.Drawing.FontStyle.Bold)
        Me.txtVoltage.Location = New System.Drawing.Point(328, 169)
        Me.txtVoltage.Name = "txtVoltage"
        Me.txtVoltage.Size = New System.Drawing.Size(78, 40)
        Me.txtVoltage.TabIndex = 9
        Me.txtVoltage.Text = "3.5"
        Me.txtVoltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BtnCalculate
        '
        Me.BtnCalculate.BackColor = System.Drawing.Color.Black
        Me.BtnCalculate.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.BtnCalculate.FlatAppearance.BorderSize = 2
        Me.BtnCalculate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.BtnCalculate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BtnCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCalculate.Font = New System.Drawing.Font("Nyet Bold Italic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCalculate.ForeColor = System.Drawing.Color.Red
        Me.BtnCalculate.Location = New System.Drawing.Point(237, 300)
        Me.BtnCalculate.Name = "BtnCalculate"
        Me.BtnCalculate.Size = New System.Drawing.Size(182, 48)
        Me.BtnCalculate.TabIndex = 10
        Me.BtnCalculate.Text = "Calculate"
        Me.BtnCalculate.UseVisualStyleBackColor = False
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.Black
        Me.BtnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnReset.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.BtnReset.FlatAppearance.BorderSize = 2
        Me.BtnReset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.BtnReset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BtnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReset.Font = New System.Drawing.Font("Nyet Bold Italic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReset.ForeColor = System.Drawing.Color.Red
        Me.BtnReset.Location = New System.Drawing.Point(469, 300)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(182, 48)
        Me.BtnReset.TabIndex = 11
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'frmCoilCalculator
        '
        Me.AcceptButton = Me.BtnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(120.0!, 120.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.BackColor = System.Drawing.Color.Black
        Me.CancelButton = Me.BtnReset
        Me.ClientSize = New System.Drawing.Size(889, 379)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.BtnCalculate)
        Me.Controls.Add(Me.txtVoltage)
        Me.Controls.Add(Me.txtCoilResist)
        Me.Controls.Add(Me.txtBatteryRating)
        Me.Controls.Add(Me.lblWattage)
        Me.Controls.Add(Me.lblCurrent)
        Me.Controls.Add(Me.lblSafe)
        Me.Controls.Add(Me.lblVoltage)
        Me.Controls.Add(Me.lblCoil)
        Me.Controls.Add(Me.lblBattery)
        Me.Controls.Add(Me.lblTitle)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmCoilCalculator"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Quick and Dirty Coil Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblBattery As Label
    Friend WithEvents ToolTipBattery As ToolTip
    Friend WithEvents lblCoil As Label
    Friend WithEvents lblVoltage As Label
    Friend WithEvents lblSafe As Label
    Friend WithEvents lblCurrent As Label
    Friend WithEvents lblWattage As Label
    Friend WithEvents txtBatteryRating As TextBox
    Friend WithEvents ToolTipCoil As ToolTip
    Friend WithEvents txtCoilResist As TextBox
    Friend WithEvents ToolTipVoltage As ToolTip
    Friend WithEvents txtVoltage As TextBox
    Friend WithEvents BtnCalculate As Button
    Friend WithEvents BtnReset As Button
End Class
