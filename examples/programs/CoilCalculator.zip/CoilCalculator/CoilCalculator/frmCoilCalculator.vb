﻿'Application Name:  Quick and Dirty Coil Calculator
'Author:            Devon Nelson
'Revision Date:     November 15, 2019
'Purpose:           This app is a quick calculator to determine whether a coil's resistence is safe
'                   to use with the battery it's paired with. The user inputs the saftey rating and peak
'                   voltage for their battery, as well as the resistence of their current coil. The program
'                   then performs calculations according to ohms law to find the current (voltage / resistance), wattage that the coil will
'                   draw from the battery (voltage x current), whether or not the power draw is safe with it's 
'                   paired battery (is battery rating > current)

Option Strict On

Public Class frmCoilCalculator

    'declare default values for text boxes
    Dim strDefaultRating As String = "35"
    Dim strDefaultCoil As String = "0.95"
    Dim strDefaultVoltage As String = "3.5"



    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles BtnCalculate.Click

        'declaration of variables for inputs and outputs

        Dim decCoilResistance As Decimal
        Dim decBatteryRating As Decimal
        Dim decBatteryVoltage As Decimal
        Dim blnResult As Boolean = False
        Dim decWattage As Decimal
        Dim decAmperage As Decimal
        Dim blnResistanceCheck As Boolean = False
        Dim blnRatingCheck As Boolean = False
        Dim blnVoltageCheck As Boolean = False

        'entries to be passed to validation function
        Dim strRating As String = txtBatteryRating.Text
        Dim strResistance As String = txtCoilResist.Text
        Dim strVoltage As String = txtVoltage.Text



        'error messages to be passed to validation function
        Dim strMessageBoxResistance As String = "Please enter a numeric value greater than zero for coil resistance "
        Dim strMessageBoxRating As String = "Please enter a numeric value greater than zero for battery rating "
        Dim strMessageBoxVoltage As String = "Please enter a numeric value greater than zero for peak voltage "



        'validate entries
        blnRatingCheck = ValidateEntry(strRating, strMessageBoxRating)
        blnResistanceCheck = ValidateEntry(strResistance, strMessageBoxResistance)
        blnVoltageCheck = ValidateEntry(strVoltage, strMessageBoxVoltage)

        If blnRatingCheck And blnResistanceCheck And blnVoltageCheck = True Then


            'pull input from text boxes into variables
            decCoilResistance = Convert.ToDecimal(txtCoilResist.Text)
            decBatteryRating = Convert.ToDecimal(txtBatteryRating.Text)
            decBatteryVoltage = Convert.ToDecimal(txtVoltage.Text)


            'perform calculation to find current
            decAmperage = decBatteryVoltage / decCoilResistance

            'perform calculation to find wattage
            decWattage = decAmperage * decBatteryVoltage

            'compare coil current to battery rating

            If decBatteryRating > decAmperage Then
                blnResult = True
            Else
                blnResult = False

            End If

            'set result message and make label visible
            If blnResult = True Then
                lblSafe.Text = "This coil is Safe!"
                lblSafe.ForeColor = Color.Lime
            Else
                lblSafe.Text = "This coil is NOT SAFE!"
                lblSafe.ForeColor = Color.Red
            End If

            lblSafe.Visible = True

            'display amperage

            lblCurrent.Text = "Current: " & decAmperage.ToString("f") & " amps"
            lblCurrent.Visible = True

            'display wattage

            lblWattage.Text = "Wattage: " & decWattage.ToString("F") & " watts"
            lblWattage.Visible = True

        ElseIf blnVoltageCheck = False Then
            txtVoltage.Clear()
            txtVoltage.Focus()
        ElseIf blnResistanceCheck = False Then
            txtCoilResist.Clear()
            txtCoilResist.Focus()
        ElseIf blnRatingCheck = False Then
            txtBatteryRating.Clear()
            txtBatteryRating.Focus()


        End If
    End Sub

    Private Function ValidateEntry(ByVal strEntry As String, ByVal strMessageBoxEntry As String) As Boolean

        Dim blnEntryCheck As Boolean = False
        Dim strMessageBoxTitle As String = "Invalid Entry"
        Dim decEntry As Decimal

        Try

            decEntry = Convert.ToDecimal(strEntry)
            If decEntry > 0 Then
                blnEntryCheck = True

            Else
                MsgBox(strMessageBoxEntry, , strMessageBoxTitle)

            End If

        Catch Exception As FormatException
            MsgBox(strMessageBoxEntry, , strMessageBoxTitle)

        Catch Exception As OverflowException
            MsgBox(strMessageBoxEntry, , strMessageBoxTitle)

        Catch Exception As SystemException
            MsgBox(strMessageBoxEntry, , strMessageBoxTitle)




        End Try
        Return blnEntryCheck
    End Function

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        lblSafe.Text = " "
        lblSafe.Visible = False
        lblCurrent.Text = "Current:"
        lblCurrent.Visible = False
        lblWattage.Text = "Wattage:"
        lblWattage.Visible = False
        txtCoilResist.Focus()
        txtBatteryRating.Text = strDefaultRating
        txtCoilResist.Text = strDefaultCoil
        txtVoltage.Text = strDefaultVoltage

    End Sub
End Class
