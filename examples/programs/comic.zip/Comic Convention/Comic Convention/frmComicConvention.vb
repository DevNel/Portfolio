﻿'   Program Name:   Decking Cost Calculator Application
'   Author:         Devon Nelson
'   Date:           October 17, 2019
'   Purpose:        This Windows Classic Desktop application computes the registration cost of 
'                   attending a Comic Convention.

Option Strict On


Public Class frmComicConvention
    Private Sub FrmComicConvention_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'This even handler is executed when the form is loaded. It sets the focus to txtFootage and clears lblCostEstimate

        txtGroupSize.Focus()
        lblCost.Text = ""

    End Sub

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        '   The btnCalculate event handler calculates the cost of attending the convention
        '   based on the amount of tickets put into txtGroupSize multiplied by the cost of the selected 
        '   radio button

        '   Declarations
        Dim decGroup As Decimal
        Dim decCostPerTicket As Decimal
        Dim decTotalCost As Decimal
        Dim decSuperhero As Decimal = 380D
        Dim decAutograph As Decimal = 275D
        Dim decConvention As Decimal = 209D

        '   Check that txtGroupSize is numeric, and if yes convert to decimal

        If IsNumeric(txtGroupSize.Text) Then
            decGroup = Convert.ToDecimal(txtGroupSize.Text)

            'check that decGroupSize is greater than 0
            If decGroup > 0 Then

                'check that decGroupSize is less than 20
                If decGroup < 20 Then

                    'check if radSuperhero is checked
                    If radSuperhero.Checked Then

                        'if yes, set decCostPerTicket to decSuperhero
                        decCostPerTicket = decSuperhero

                        'else check if radAutograph is checked
                    ElseIf radAutograph.Checked Then

                        'set decCostPerTicket to decAutograph
                        decCostPerTicket = decAutograph

                        'else check if radCon is checked
                    ElseIf radCon.Checked Then

                        'set decCostPerTicket to decConvention
                        decCostPerTicket = decConvention
                    End If

                Else

                    'display error if user entered a value of less than do
                    MsgBox("Please Enter a Value Under 20")
                    txtGroupSize.Text = ""
                    txtGroupSize.Focus()

                End If


                'calculate and display cost converted to string displayed as currency
                decTotalCost = decCostPerTicket * decGroup
                lblCost.Text = decTotalCost.ToString("C")

            Else


                'Display error if user entered a negative value in txtGroupSize, reset and refocus
                MsgBox("You Entered " & decGroup.ToString() & ". Enter a Positive Number", , "Input Error")
                txtGroupSize.Text = ""
                txtGroupSize.Focus()


            End If

        Else


            'display Error for nonnumeric value in txtGroupSize
            MsgBox("Enter the size of your group.", , "Input Error")
            txtGroupSize.Text = ""
            txtGroupSize.Focus()

        End If
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'this event handler is executed when btnClear is clicked. It clears txtGroupsize and lblCost
        'resets the radio buttons and sets the focus to txtGroupSize

        txtGroupSize.Clear()
        lblCost.Text = ""
        radSuperhero.Checked = True
        radAutograph.Checked = False
        radCon.Checked = False
        txtGroupSize.Focus()


    End Sub
End Class
