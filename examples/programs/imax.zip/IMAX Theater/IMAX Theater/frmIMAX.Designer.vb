﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmIMAX
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblIMAX = New System.Windows.Forms.Label()
        Me.cboShowtime = New System.Windows.Forms.ComboBox()
        Me.lblNumberofTickets = New System.Windows.Forms.Label()
        Me.txtNumberofTickets = New System.Windows.Forms.TextBox()
        Me.btnTicketCost = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblIMAX
        '
        Me.lblIMAX.AutoSize = True
        Me.lblIMAX.BackColor = System.Drawing.Color.CornflowerBlue
        Me.lblIMAX.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIMAX.ForeColor = System.Drawing.Color.White
        Me.lblIMAX.Location = New System.Drawing.Point(489, 42)
        Me.lblIMAX.Name = "lblIMAX"
        Me.lblIMAX.Size = New System.Drawing.Size(315, 33)
        Me.lblIMAX.TabIndex = 0
        Me.lblIMAX.Text = "IMAX Theatre Tickets"
        '
        'cboShowtime
        '
        Me.cboShowtime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboShowtime.FormattingEnabled = True
        Me.cboShowtime.Items.AddRange(New Object() {"Matinee - $16", "Evening - $27"})
        Me.cboShowtime.Location = New System.Drawing.Point(557, 113)
        Me.cboShowtime.Name = "cboShowtime"
        Me.cboShowtime.Size = New System.Drawing.Size(178, 28)
        Me.cboShowtime.TabIndex = 1
        Me.cboShowtime.Text = "Select Showtime"
        '
        'lblNumberofTickets
        '
        Me.lblNumberofTickets.AutoSize = True
        Me.lblNumberofTickets.BackColor = System.Drawing.Color.Transparent
        Me.lblNumberofTickets.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumberofTickets.Location = New System.Drawing.Point(569, 179)
        Me.lblNumberofTickets.Name = "lblNumberofTickets"
        Me.lblNumberofTickets.Size = New System.Drawing.Size(154, 20)
        Me.lblNumberofTickets.TabIndex = 2
        Me.lblNumberofTickets.Text = "Number of Tickets"
        Me.lblNumberofTickets.Visible = False
        '
        'txtNumberofTickets
        '
        Me.txtNumberofTickets.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtNumberofTickets.Location = New System.Drawing.Point(626, 237)
        Me.txtNumberofTickets.Name = "txtNumberofTickets"
        Me.txtNumberofTickets.Size = New System.Drawing.Size(40, 26)
        Me.txtNumberofTickets.TabIndex = 3
        Me.txtNumberofTickets.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtNumberofTickets.Visible = False
        '
        'btnTicketCost
        '
        Me.btnTicketCost.BackColor = System.Drawing.Color.CornflowerBlue
        Me.btnTicketCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold)
        Me.btnTicketCost.ForeColor = System.Drawing.Color.White
        Me.btnTicketCost.Location = New System.Drawing.Point(555, 298)
        Me.btnTicketCost.Name = "btnTicketCost"
        Me.btnTicketCost.Size = New System.Drawing.Size(183, 44)
        Me.btnTicketCost.TabIndex = 4
        Me.btnTicketCost.Text = "Ticket Cost"
        Me.btnTicketCost.UseVisualStyleBackColor = False
        Me.btnTicketCost.Visible = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.CornflowerBlue
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.Location = New System.Drawing.Point(555, 365)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(183, 44)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Visible = False
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.CornflowerBlue
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblTotal.ForeColor = System.Drawing.Color.White
        Me.lblTotal.Location = New System.Drawing.Point(527, 435)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(239, 26)
        Me.lblTotal.TabIndex = 6
        Me.lblTotal.Text = "IMAX Theatre Tickets"
        Me.lblTotal.Visible = False
        '
        'frmIMAX
        '
        Me.AcceptButton = Me.btnTicketCost
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.IMAX_Theater.My.Resources.Resources.imax
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(856, 516)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnTicketCost)
        Me.Controls.Add(Me.txtNumberofTickets)
        Me.Controls.Add(Me.lblNumberofTickets)
        Me.Controls.Add(Me.cboShowtime)
        Me.Controls.Add(Me.lblIMAX)
        Me.Name = "frmIMAX"
        Me.Text = "Purchase IMAX Theatre Tickets"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblIMAX As Label
    Friend WithEvents cboShowtime As ComboBox
    Friend WithEvents lblNumberofTickets As Label
    Friend WithEvents txtNumberofTickets As TextBox
    Friend WithEvents btnTicketCost As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lblTotal As Label
End Class
