﻿'  Program Name:   IMAX Theatre
'  Author:         Devon Nelson
'  Date:           November 14, 2019
'  Purpose:        This Windows Classic Desktop application computes the cost of matinee and evening tickets with varying base and data plans.


Public Class frmIMAX

    'declarations
    Dim intShowtimePrice As Integer
    Dim intMatPrice As Integer = 16
    Dim intEvePrice As Integer = 27
    Dim intTotalCost As Integer



    Private Sub FrmIMAX_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'hold splash screen for 4 seconds
        Threading.Thread.Sleep(4000)
    End Sub

    Private Sub CboShowtime_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboShowtime.SelectedIndexChanged
        '   This even handler allows the user to chose a showtime and calls subprocedures to allow the user to enter a number of tickets

        Dim intShowtimeChoice As Integer

        intShowtimeChoice = cboShowtime.SelectedIndex

        Select Case intShowtimeChoice
            Case 0
                intShowtimePrice = intMatPrice

            Case 1
                intShowtimePrice = intEvePrice


        End Select

        'make other items in window visible
        lblNumberofTickets.Visible = True
        txtNumberofTickets.Visible = True
        btnTicketCost.Visible = True
        btnClear.Visible = True
        lblTotal.Visible = True

        'clear number textbox and total label
        txtNumberofTickets.Clear()
        lblTotal.Text = ""



    End Sub

    Private Sub BtnTicketCost_Click(sender As Object, e As EventArgs) Handles btnTicketCost.Click

        Dim intNumberofTickets As Integer
        Dim blnNumberofTicketsValid As Boolean = False

        'call a function to ensure the number of tickets is valid
        blnNumberofTicketsValid = ValidateNumberofTickets()

        'if The number of tickets is valid then calculate cost
        If blnNumberofTicketsValid = True Then
            intNumberofTickets = Convert.ToInt32(txtNumberofTickets.Text)
            intTotalCost = intNumberofTickets * intShowtimePrice

            lblTotal.Text = intTotalCost.ToString("C") & " for the tickets"
        End If



    End Sub

    Private Function ValidateNumberofTickets() As Boolean
        Dim intPartySize As Integer
        Dim blnValidtyCheck As Boolean = False
        Dim strNumberofTicketsMessage As String = "Please enter a number of tickets greater than zero."
        Dim strMessageBoxTitle As String = "Error"

        Try
            intPartySize = Convert.ToInt32(txtNumberofTickets.Text)

            If intPartySize > 0 Then
                blnValidtyCheck = True

            Else
                MsgBox(strNumberofTicketsMessage, , strMessageBoxTitle)
                txtNumberofTickets.Clear()
                txtNumberofTickets.Focus()
            End If
        Catch exception As FormatException
            MsgBox(strNumberofTicketsMessage, , strMessageBoxTitle)
            txtNumberofTickets.Focus()
            txtNumberofTickets.Clear()
        Catch exception As OverflowException
            MsgBox(strNumberofTicketsMessage, , strMessageBoxTitle)
            txtNumberofTickets.Focus()
            txtNumberofTickets.Clear()
        Catch exception As SystemException
            MsgBox(strNumberofTicketsMessage, , strMessageBoxTitle)
            txtNumberofTickets.Focus()
            txtNumberofTickets.Clear()

        End Try
        Return blnValidtyCheck
    End Function

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'this event handler clears the form and resets it for use when the user clicks the clear button

        cboShowtime.Text = "Select Showtime:"
        cboShowtime.Focus()
        lblNumberofTickets.Visible = False
        txtNumberofTickets.Visible = False
        btnTicketCost.Visible = False
        btnClear.Visible = False
        lblTotal.Visible = False
        lblTotal.Text = ""
    End Sub
End Class
