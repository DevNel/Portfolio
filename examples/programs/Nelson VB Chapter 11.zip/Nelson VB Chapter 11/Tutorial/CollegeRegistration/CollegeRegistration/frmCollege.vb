﻿'Program:       College Registration Costs
'Developer:     Devon Nelson
'Date:          December 12, 2019
'Purpose:       This program calculates the registration costs for a college student. It also records the costs in a text file.

Option Strict On


Public Class frmCollege
    Private Sub BtnCalculateCosts_Click(sender As Object, e As EventArgs) Handles btnCalculateCosts.Click

        'This Calculate Costs button click event handler edits the registration(costs) form to ensure it contains valid data.
        'THen, after passing control to the business class, it displays the cost.

        Dim objStudent As Student
        Dim objOnCampusStudent As OnCampusStudent
        Dim InputError As Boolean = False

        ' Is student ID entered properly
        If txtStudentID.MaskFull = False Then
            MsgBox("Enter your Student ID in the Student ID box", , "Error")
            txtStudentID.Clear()
            txtStudentID.Focus()
            InputError = True

            'Is student name entered properly
        ElseIf txtStudentName.TextLength < 1 Or txtStudentName.Text < "A" Then
            MsgBox("Enter your name in the Student Name box", , "Error")
            txtStudentName.Clear()
            txtStudentName.Focus()
            InputError = True

            'is the number of units entered properly
        ElseIf Not IsNumeric(txtUnits.Text) Then
            MsgBox("Enter the units in the Number of Units box", , "Error")
            txtUnits.Clear()
            txtUnits.Focus()
            InputError = True

            'has 1-24 units been entered
        ElseIf Convert.ToInt32(txtUnits.Text) < 1 Or Convert.ToInt32(txtUnits.Text) > 24 Then
            MsgBox("Units must be 1 - 24", , "Error")
            txtUnits.Clear()
            txtUnits.Focus()
            InputError = True

            'has a major been selecte
        ElseIf cboMajor.SelectedIndex < 0 Then
            MsgBox("Please select a major", , "Error")
            cboMajor.Focus()
            InputError = True
        End If

        'if no input  error, process the registration costs
        If Not InputError Then
            If radOffCampus.Checked Then
                objStudent = New Student(txtStudentID.Text, txtStudentName.Text, Convert.ToString(cboMajor.SelectedItem), txtUnits.Text)
                lblTotalCosts.Visible = True
                lblTotalCosts.Text = "Total semester costs are: " & (objStudent.ComputeCosts()).ToString("C2")
            Else
                objOnCampusStudent = New OnCampusStudent(txtStudentID.Text, txtStudentName.Text, Convert.ToString(cboMajor.SelectedItem), txtUnits.Text,
                radCooperDorm.Checked, radCraigHall.Checked, radJulianSuites.Checked)

                lblTotalCosts.Visible = True
                lblTotalCosts.Text = "Total semester costs are: " & (objOnCampusStudent.ComputeCosts()).ToString("C2")

            End If
        End If
    End Sub

    Private Sub RadOffCampus_CheckedChanged(sender As Object, e As EventArgs) Handles radOffCampus.CheckedChanged
        'this event handler is executed when the Off campus radio button is selected. It hides the housing/board radio buttons

        grpHousing.Visible = False

    End Sub

    Private Sub RadOnCampus_CheckedChanged(sender As Object, e As EventArgs) Handles radOnCampus.CheckedChanged
        'this event handler is executed when the on campus radio button is selected. it unhides the housing/board radio buttons

        grpHousing.Visible = True

    End Sub

    Private Sub BtnClearForm_Click(sender As Object, e As EventArgs) Handles btnClearForm.Click
        'this event handler is executed when the clear form button is clicked and clears student id, student name, and unit text boxes as well as
        'clears selection in the major combo box, grp housing and grp residence and hides lblTotalCosts Then it changes focus to Student ID

        txtStudentID.Clear()
        txtStudentName.Clear()
        txtUnits.Clear()
        cboMajor.SelectedIndex = -1
        cboMajor.Text = "Choose a Major"
        radCooperDorm.Checked = True
        radOffCampus.Checked = True
        grpHousing.Visible = False
        lblTotalCosts.Visible = False
        txtStudentID.Focus()

    End Sub
End Class
