﻿'Class:     Student
'Developer: Devon Nelson
'Date:      December 12, 2019
'Purpose:   This business class for registering college studend calculates the semester cost for tuition. It also causes the student cost file to be written.

Option Strict On

Public Class Student

    'class Variables
    Protected _strStudentID As String
    Protected _strStudentName As String
    Protected _strMajor As String
    Protected _intUnits As Integer
    Protected _decCosts As Decimal
    Protected _decCostsPerUnit As Decimal = 450D

    Dim objStudentCostsFile As StudentCostsFile

    Sub New(ByVal strStudentID As String, ByVal strStudentName As String, ByVal strMajor As String, ByVal intUnits As String)

        'This subprocedure is a constructor for the student class. it is called when the object is instantiated with arguments

        'the following code assigns the arguments to class variables

        _strStudentID = strStudentID
        _strStudentName = strStudentName
        _strMajor = strMajor
        _intUnits = Convert.ToInt32(intUnits)


    End Sub

    Overridable Function ComputeCosts() As Decimal

        'This function computes the registration costs, writes a record in the student costs file and returns the registration costs

        'calculate costs
        _decCosts = _intUnits * _decCostsPerUnit

        'write the student record
        objStudentCostsFile = New StudentCostsFile(_strStudentID, _strStudentName, _strMajor, _decCosts)
        objStudentCostsFile.WriteRecord()

        'return the calculated cost
        Return _decCosts

    End Function

End Class
