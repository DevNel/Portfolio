﻿'Class:     OnCampusStudent
'Developer: Devon Nelson
'Date:      December 12 2019
'Purpose:   This business class for registering an on-campus college studen calculates the semester costs, including tuition
'           and housing. It also causes the student costs file to be written

Option Strict On



Public Class OnCampusStudent
    Inherits Student

    'class variables
    Private _Cooper As Boolean
    Private _Craig As Boolean
    Private _Julian As Boolean

    Dim objStudentCostsFile As StudentCostsFile

    Sub New(ByVal StudentID As String, ByVal StudentName As String, ByVal Major As String, ByVal Units As String, ByVal Cooper As Boolean,
            ByVal Craig As Boolean, ByVal Julian As Boolean)

        'this subprocedure is a constructor for the student class. it is called when instantiated with arguments

        MyBase.New(StudentID, StudentName, Major, Units)

        'The following code assigns the arguments to class variables

        _Cooper = Cooper
        _Craig = Craig
        _Julian = Julian


    End Sub

    Overrides Function ComputeCosts() As Decimal

        'This function computes the registration costs, writes a record in the student costs file and returns the registration costs

        'define variables

        Dim HousingCost As Decimal
        Const cdecCooperHousingCost As Decimal = 2900D
        Const cdecCraigHousingCost As Decimal = 3400D
        Const cdecJulianHousingCost As Decimal = 4000D

        'calculate the cost
        If _Cooper Then
            HousingCost = cdecCooperHousingCost
        ElseIf _Craig Then
            HousingCost = cdecCraigHousingCost
        ElseIf _Julian Then
            HousingCost = cdecJulianHousingCost

        End If

        _decCosts = (_intUnits * _decCostsPerUnit) + HousingCost

        'write the student record

        objStudentCostsFile = New StudentCostsFile(_strStudentID, _strStudentName, _strMajor, _decCosts)
        objStudentCostsFile.WriteRecord()


        'return the calculated cost
        Return _decCosts

    End Function
End Class
