﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCollege
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picCollege = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtStudentName = New System.Windows.Forms.TextBox()
        Me.txtUnits = New System.Windows.Forms.TextBox()
        Me.grpResidence = New System.Windows.Forms.GroupBox()
        Me.radOffCampus = New System.Windows.Forms.RadioButton()
        Me.radOnCampus = New System.Windows.Forms.RadioButton()
        Me.txtStudentID = New System.Windows.Forms.MaskedTextBox()
        Me.grpHousing = New System.Windows.Forms.GroupBox()
        Me.radCraigHall = New System.Windows.Forms.RadioButton()
        Me.radCooperDorm = New System.Windows.Forms.RadioButton()
        Me.radJulianSuites = New System.Windows.Forms.RadioButton()
        Me.cboMajor = New System.Windows.Forms.ComboBox()
        Me.lblMajor = New System.Windows.Forms.Label()
        Me.btnCalculateCosts = New System.Windows.Forms.Button()
        Me.btnClearForm = New System.Windows.Forms.Button()
        Me.lblTotalCosts = New System.Windows.Forms.Label()
        CType(Me.picCollege, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpResidence.SuspendLayout()
        Me.grpHousing.SuspendLayout()
        Me.SuspendLayout()
        '
        'picCollege
        '
        Me.picCollege.Image = Global.CollegeRegistration.My.Resources.Resources.college
        Me.picCollege.Location = New System.Drawing.Point(1, 1)
        Me.picCollege.Name = "picCollege"
        Me.picCollege.Size = New System.Drawing.Size(235, 157)
        Me.picCollege.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCollege.TabIndex = 0
        Me.picCollege.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Navy
        Me.lblTitle.Location = New System.Drawing.Point(354, 40)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(332, 78)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Register for Classes" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Bedford College"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentID.ForeColor = System.Drawing.Color.Navy
        Me.lblStudentID.Location = New System.Drawing.Point(42, 180)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(91, 19)
        Me.lblStudentID.TabIndex = 0
        Me.lblStudentID.Text = "Student ID:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.Location = New System.Drawing.Point(42, 212)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(42, 244)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 19)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Number of Units:"
        '
        'txtStudentName
        '
        Me.txtStudentName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentName.ForeColor = System.Drawing.Color.Navy
        Me.txtStudentName.Location = New System.Drawing.Point(188, 211)
        Me.txtStudentName.Name = "txtStudentName"
        Me.txtStudentName.Size = New System.Drawing.Size(100, 21)
        Me.txtStudentName.TabIndex = 2
        '
        'txtUnits
        '
        Me.txtUnits.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUnits.ForeColor = System.Drawing.Color.Navy
        Me.txtUnits.Location = New System.Drawing.Point(188, 243)
        Me.txtUnits.Name = "txtUnits"
        Me.txtUnits.Size = New System.Drawing.Size(34, 21)
        Me.txtUnits.TabIndex = 3
        '
        'grpResidence
        '
        Me.grpResidence.Controls.Add(Me.radOnCampus)
        Me.grpResidence.Controls.Add(Me.radOffCampus)
        Me.grpResidence.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpResidence.ForeColor = System.Drawing.Color.Navy
        Me.grpResidence.Location = New System.Drawing.Point(44, 280)
        Me.grpResidence.Name = "grpResidence"
        Me.grpResidence.Size = New System.Drawing.Size(144, 68)
        Me.grpResidence.TabIndex = 4
        Me.grpResidence.TabStop = False
        Me.grpResidence.Text = "Residence"
        '
        'radOffCampus
        '
        Me.radOffCampus.AutoSize = True
        Me.radOffCampus.Checked = True
        Me.radOffCampus.Location = New System.Drawing.Point(7, 21)
        Me.radOffCampus.Name = "radOffCampus"
        Me.radOffCampus.Size = New System.Drawing.Size(83, 17)
        Me.radOffCampus.TabIndex = 5
        Me.radOffCampus.TabStop = True
        Me.radOffCampus.Text = "Off-Campus"
        Me.radOffCampus.UseVisualStyleBackColor = True
        '
        'radOnCampus
        '
        Me.radOnCampus.AutoSize = True
        Me.radOnCampus.Location = New System.Drawing.Point(7, 45)
        Me.radOnCampus.Name = "radOnCampus"
        Me.radOnCampus.Size = New System.Drawing.Size(81, 17)
        Me.radOnCampus.TabIndex = 6
        Me.radOnCampus.Text = "On-Campus"
        Me.radOnCampus.UseVisualStyleBackColor = True
        '
        'txtStudentID
        '
        Me.txtStudentID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentID.ForeColor = System.Drawing.Color.Navy
        Me.txtStudentID.Location = New System.Drawing.Point(188, 179)
        Me.txtStudentID.Mask = "000-00-0000"
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.Size = New System.Drawing.Size(73, 21)
        Me.txtStudentID.TabIndex = 1
        '
        'grpHousing
        '
        Me.grpHousing.Controls.Add(Me.radJulianSuites)
        Me.grpHousing.Controls.Add(Me.radCraigHall)
        Me.grpHousing.Controls.Add(Me.radCooperDorm)
        Me.grpHousing.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpHousing.ForeColor = System.Drawing.Color.Navy
        Me.grpHousing.Location = New System.Drawing.Point(322, 280)
        Me.grpHousing.Name = "grpHousing"
        Me.grpHousing.Size = New System.Drawing.Size(144, 96)
        Me.grpHousing.TabIndex = 7
        Me.grpHousing.TabStop = False
        Me.grpHousing.Text = "Housing/Board"
        Me.grpHousing.Visible = False
        '
        'radCraigHall
        '
        Me.radCraigHall.AutoSize = True
        Me.radCraigHall.Location = New System.Drawing.Point(7, 45)
        Me.radCraigHall.Name = "radCraigHall"
        Me.radCraigHall.Size = New System.Drawing.Size(70, 17)
        Me.radCraigHall.TabIndex = 9
        Me.radCraigHall.Text = "Craig Hall"
        Me.radCraigHall.UseVisualStyleBackColor = True
        '
        'radCooperDorm
        '
        Me.radCooperDorm.AutoSize = True
        Me.radCooperDorm.Checked = True
        Me.radCooperDorm.Location = New System.Drawing.Point(7, 21)
        Me.radCooperDorm.Name = "radCooperDorm"
        Me.radCooperDorm.Size = New System.Drawing.Size(88, 17)
        Me.radCooperDorm.TabIndex = 8
        Me.radCooperDorm.TabStop = True
        Me.radCooperDorm.Text = "Cooper Dorm"
        Me.radCooperDorm.UseVisualStyleBackColor = True
        '
        'radJulianSuites
        '
        Me.radJulianSuites.AutoSize = True
        Me.radJulianSuites.Location = New System.Drawing.Point(6, 68)
        Me.radJulianSuites.Name = "radJulianSuites"
        Me.radJulianSuites.Size = New System.Drawing.Size(84, 17)
        Me.radJulianSuites.TabIndex = 10
        Me.radJulianSuites.Text = "Julian Suites"
        Me.radJulianSuites.UseVisualStyleBackColor = True
        '
        'cboMajor
        '
        Me.cboMajor.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboMajor.ForeColor = System.Drawing.Color.Navy
        Me.cboMajor.FormattingEnabled = True
        Me.cboMajor.Items.AddRange(New Object() {"Programming"})
        Me.cboMajor.Location = New System.Drawing.Point(600, 280)
        Me.cboMajor.Name = "cboMajor"
        Me.cboMajor.Size = New System.Drawing.Size(157, 21)
        Me.cboMajor.TabIndex = 11
        Me.cboMajor.Text = "Select a Major"
        '
        'lblMajor
        '
        Me.lblMajor.AutoSize = True
        Me.lblMajor.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMajor.ForeColor = System.Drawing.Color.Navy
        Me.lblMajor.Location = New System.Drawing.Point(539, 280)
        Me.lblMajor.Name = "lblMajor"
        Me.lblMajor.Size = New System.Drawing.Size(55, 19)
        Me.lblMajor.TabIndex = 0
        Me.lblMajor.Text = "Major:"
        '
        'btnCalculateCosts
        '
        Me.btnCalculateCosts.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateCosts.ForeColor = System.Drawing.Color.Navy
        Me.btnCalculateCosts.Location = New System.Drawing.Point(202, 411)
        Me.btnCalculateCosts.Name = "btnCalculateCosts"
        Me.btnCalculateCosts.Size = New System.Drawing.Size(128, 37)
        Me.btnCalculateCosts.TabIndex = 12
        Me.btnCalculateCosts.Text = "Calculate Costs"
        Me.btnCalculateCosts.UseVisualStyleBackColor = True
        '
        'btnClearForm
        '
        Me.btnClearForm.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClearForm.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearForm.ForeColor = System.Drawing.Color.Navy
        Me.btnClearForm.Location = New System.Drawing.Point(471, 411)
        Me.btnClearForm.Name = "btnClearForm"
        Me.btnClearForm.Size = New System.Drawing.Size(128, 37)
        Me.btnClearForm.TabIndex = 13
        Me.btnClearForm.Text = "Clear Form"
        Me.btnClearForm.UseVisualStyleBackColor = True
        '
        'lblTotalCosts
        '
        Me.lblTotalCosts.AutoSize = True
        Me.lblTotalCosts.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCosts.ForeColor = System.Drawing.Color.Navy
        Me.lblTotalCosts.Location = New System.Drawing.Point(282, 478)
        Me.lblTotalCosts.Name = "lblTotalCosts"
        Me.lblTotalCosts.Size = New System.Drawing.Size(236, 19)
        Me.lblTotalCosts.TabIndex = 0
        Me.lblTotalCosts.Text = "Total semester costs are: $2700"
        Me.lblTotalCosts.Visible = False
        '
        'frmCollege
        '
        Me.AcceptButton = Me.btnCalculateCosts
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClearForm
        Me.ClientSize = New System.Drawing.Size(800, 524)
        Me.Controls.Add(Me.lblTotalCosts)
        Me.Controls.Add(Me.btnClearForm)
        Me.Controls.Add(Me.btnCalculateCosts)
        Me.Controls.Add(Me.lblMajor)
        Me.Controls.Add(Me.cboMajor)
        Me.Controls.Add(Me.grpHousing)
        Me.Controls.Add(Me.txtStudentID)
        Me.Controls.Add(Me.grpResidence)
        Me.Controls.Add(Me.txtUnits)
        Me.Controls.Add(Me.txtStudentName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picCollege)
        Me.Name = "frmCollege"
        Me.Text = "College Registration Costs"
        CType(Me.picCollege, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpResidence.ResumeLayout(False)
        Me.grpResidence.PerformLayout()
        Me.grpHousing.ResumeLayout(False)
        Me.grpHousing.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picCollege As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblStudentID As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtStudentName As TextBox
    Friend WithEvents txtUnits As TextBox
    Friend WithEvents grpResidence As GroupBox
    Friend WithEvents radOnCampus As RadioButton
    Friend WithEvents radOffCampus As RadioButton
    Friend WithEvents txtStudentID As MaskedTextBox
    Friend WithEvents grpHousing As GroupBox
    Friend WithEvents radJulianSuites As RadioButton
    Friend WithEvents radCraigHall As RadioButton
    Friend WithEvents radCooperDorm As RadioButton
    Friend WithEvents cboMajor As ComboBox
    Friend WithEvents lblMajor As Label
    Friend WithEvents btnCalculateCosts As Button
    Friend WithEvents btnClearForm As Button
    Friend WithEvents lblTotalCosts As Label
End Class
