﻿'Class:     Student Costs File
'Developer:Devon Nelson
'Date:      December 12, 2019
'Purpose:   This claass represents the Student Costs File. The WriteRecord Procedure writes a coma-delimited student costs file that contains
'           the Student ID, Student Name, Major, and Student Costs.

Option Strict On


Public Class StudentCostsFile

    'class variables

    Private _strStudentID As String
    Private _strStudentName As String
    Private _strMajor As String
    Private _decStudentCosts As Decimal

    Sub New(ByVal StudentID As String, ByVal StudentName As String, ByVal Major As String, ByVal Costs As Decimal)
        'this sub procedure is the constructor for the studentcostsfile

        'the following code assigns the arguments to class variables
        _strStudentID = StudentID
        _strStudentName = StudentName
        _strMajor = Major
        _decStudentCosts = Costs

    End Sub

    Sub WriteRecord()
        'this subprocedure opens the studentcosts output text file and then writes a record in the comma-delimited file

        Dim strNameandLocationOfFile As String = "d:\StudentCosts.txt"

        Try
            Dim objWriter As IO.StreamWriter = IO.File.AppendText(strNameandLocationOfFile)

            objWriter.Write(_strStudentID & ",")
            objWriter.Write(_strStudentName & ",")
            objWriter.Write(_strMajor & ",")
            objWriter.WriteLine(_decStudentCosts)
            objWriter.Close()

        Catch ex As Exception

            MsgBox("No device available - program aborted", , "Error")
            Application.Exit()

        End Try
    End Sub

End Class
