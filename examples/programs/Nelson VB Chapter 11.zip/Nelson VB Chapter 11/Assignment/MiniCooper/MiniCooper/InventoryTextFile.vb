﻿'Class: Inventory Text File
'Developer: Devon Nelson
'Date: December 12, 2019
'Purpose: This class represents the Inventory Text File. The WriteRecord Procedure writes a coma-delimited Inventory Text File
'          containging VIN, Make, Model, Year, Mileage, and Sticker Price

Option Strict On

Public Class InventoryTextFile
    'class variables

    Private _strVIN As String
    Private _strMake As String
    Private _strModel As String
    Private _strYear As String
    Private _strMileage As String
    Private _decStickerPrice As Decimal

    Sub New(ByVal strVIN As String, ByVal strMake As String, ByVal strModel As String, ByVal StrYear As String, ByVal strMileage As String, ByVal decStickerPrice As Decimal)
        'this sub procedure is the constructor for InventoryTextFile

        'the following code assigns the arguments to class variables

        _strVIN = strVIN
        _strMake = strMake
        _strModel = strModel
        _strYear = StrYear
        _strMileage = strMileage
        _decStickerPrice = decStickerPrice

    End Sub

    Sub WriteRecord()
        'this subprocedure opens the InventoryTextFile and writes a record in the comma-delimited file

        Dim strNameandLocationofFile As String = "d:\InventoryTextFile.txt"

        Try
            Dim objWriter As IO.StreamWriter = IO.File.AppendText(strNameandLocationofFile)

            objWriter.Write(_strVIN & " , ")
            objWriter.Write(_strMake & " , ")
            objWriter.Write(_strModel & " , ")
            objWriter.Write(_strYear & " , ")
            objWriter.Write(_strMileage & " , ")
            objWriter.WriteLine(_decStickerPrice.ToString("C"))
            objWriter.Close()


        Catch ex As Exception

            MsgBox("No device available - program aborted", , "Error")
            Application.Exit()

        End Try
    End Sub
End Class
