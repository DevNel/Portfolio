﻿'Class: Convertible
'Developer: Devon Nelson
'Date:  December 12, 2109
'purpose: this business class is for calculating cost of a convertible model. It also causes the information to be written to InventoryTextFile and returns the stickerprice

Option Strict On



Public Class Convertible
    Inherits Standard

    Dim objInventoryTextFile As InventoryTextFile

    Sub New(ByVal strVIN As String, ByVal strMake As String, ByVal strModel As String, ByVal strYear As String, ByVal strMileage As String, ByVal strPrice As String, ByVal strColor As String)
        'this sub procedure is a constructor for the student class. it is called when instantiated with arguments

        MyBase.New(strVIN, strMake, strModel, strYear, strMileage, strPrice, strColor)

    End Sub

    Overrides Function ComputePrice() As Decimal

        'this function computes the sticker price, writes a record in the InventoryTextFile and returns the stickerprice

        'define variables
        Const cdecConvertibleSurchargePercentage = 0.26D

        'calculate sticker price

        _decStickerPrice = _decPrice + (_decPrice * cdecConvertibleSurchargePercentage)

        'write to InventoryTextFile

        objInventoryTextFile = New InventoryTextFile(_strVIN, _strMake, _strModel, _strYear, _strMileage, _decStickerPrice)
        objInventoryTextFile.WriteRecord()

        'return calculated sticker price
        Return _decStickerPrice

    End Function




End Class
