﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMiniCooperCars = New System.Windows.Forms.Label()
        Me.txtInventoryDisplay = New System.Windows.Forms.TextBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.lblCurrentInventory = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblMiniCooperCars
        '
        Me.lblMiniCooperCars.AutoSize = True
        Me.lblMiniCooperCars.Font = New System.Drawing.Font("Imprint MT Shadow", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiniCooperCars.Location = New System.Drawing.Point(198, 9)
        Me.lblMiniCooperCars.Name = "lblMiniCooperCars"
        Me.lblMiniCooperCars.Size = New System.Drawing.Size(405, 57)
        Me.lblMiniCooperCars.TabIndex = 3
        Me.lblMiniCooperCars.Text = "Mini Cooper Cars"
        '
        'txtInventoryDisplay
        '
        Me.txtInventoryDisplay.Location = New System.Drawing.Point(12, 102)
        Me.txtInventoryDisplay.Multiline = True
        Me.txtInventoryDisplay.Name = "txtInventoryDisplay"
        Me.txtInventoryDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInventoryDisplay.Size = New System.Drawing.Size(776, 284)
        Me.txtInventoryDisplay.TabIndex = 4
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.Gray
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnReturn.ForeColor = System.Drawing.Color.White
        Me.btnReturn.Location = New System.Drawing.Point(248, 392)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(305, 43)
        Me.btnReturn.TabIndex = 20
        Me.btnReturn.Text = "Return to Inventory Entry"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'lblCurrentInventory
        '
        Me.lblCurrentInventory.AutoSize = True
        Me.lblCurrentInventory.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentInventory.Location = New System.Drawing.Point(303, 66)
        Me.lblCurrentInventory.Name = "lblCurrentInventory"
        Me.lblCurrentInventory.Size = New System.Drawing.Size(194, 25)
        Me.lblCurrentInventory.TabIndex = 21
        Me.lblCurrentInventory.Text = "Current Inventory"
        '
        'frmInventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Yellow
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblCurrentInventory)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.txtInventoryDisplay)
        Me.Controls.Add(Me.lblMiniCooperCars)
        Me.Name = "frmInventory"
        Me.Text = "Mini Cooper Dealership - Current Inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMiniCooperCars As Label
    Friend WithEvents txtInventoryDisplay As TextBox
    Friend WithEvents btnReturn As Button
    Friend WithEvents lblCurrentInventory As Label
End Class
