﻿'Class: Standard
'Developer: Devon Nelson
'Date: December 12, 2019
'Purpose:   This business class for MiniCooper inventory, calculates the sticker price of a vehicle and causes the inventory text file to be written

Option Strict On

Public Class Standard

    'class Variables
    Protected _strVIN As String
    Protected _strMake As String
    Protected _strModel As String
    Protected _strYear As String
    Protected _strMileage As String
    Protected _strPrice As String
    Protected _strColor As String
    Protected _decPrice As Decimal
    Protected _decStickerPrice As Decimal

    Dim objInventoryTextFile As InventoryTextFile

    Sub New(ByVal strVIN As String, ByVal strMake As String, ByVal strModel As String, ByVal strYear As String, ByVal strMileage As String, ByVal strPrice As String, ByVal strColor As String)
        'this subprocedure is a constructor for the standard class. it is called when the boject is instantiated with arguments

        'the following code assigns the arguments to class variables

        _strVIN = strVIN
        _strMake = strMake
        _strModel = strModel
        _strYear = strYear
        _strMileage = strMileage
        _strPrice = strPrice
        _strColor = strColor
        _decPrice = Convert.ToDecimal(strPrice)

    End Sub

    Overridable Function ComputePrice() As Decimal
        'this function computes cost, which currently does nothing, but could be modified if a standard surcharge were added
        'it writes a record in the InventoryTextFile and returns cost as a decimal

        _decStickerPrice = _decPrice

        'write to the Inventory text file

        objInventoryTextFile = New InventoryTextFile(_strVIN, _strMake, _strModel, _strYear, _strMileage, _decStickerPrice)
        objInventoryTextFile.WriteRecord()

        'return the sticker price
        Return _decStickerPrice



    End Function
End Class
