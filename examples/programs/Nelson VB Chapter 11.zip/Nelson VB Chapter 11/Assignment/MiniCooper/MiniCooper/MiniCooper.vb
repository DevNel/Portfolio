﻿'Program: Mini Cooper Dealership
'Developer: Devon Nelson
'Date:      December 12, 2019
'Purpose:   This Windows application allows the user to add cars to the inventory of a mini Cooper car dealership. The program displays the sticker price for each car and allows the
'           user to display thge inventory text file.

Option Strict On



Public Class frmMiniCooper
    Private Sub BtnStickerPrice_Click(sender As Object, e As EventArgs) Handles btnStickerPrice.Click

        'This Sticker Price button click event handler checks that VIN, MOdel, Year, Mileage, price, color, and convertible are valid
        'entries. It then passes control to the business class and displays the cost.


        Dim objStandard As Standard
        Dim objConvertible As Convertible
        Dim InputError As Boolean = False



        'is a vehicle number entered
        If txtVIN.TextLength <> 14 Then
            MsgBox("Please enter a Valid 14 digit Vehicle ID", , "Error")
            txtVIN.Clear()
            txtVIN.Focus()
            InputError = True

            'is a vehicle make entered
        ElseIf txtModel.TextLength < 1 Then
            MsgBox("Please enter a Vehicle Make", , "Error")
            txtModel.Clear()
            txtModel.Focus()
            InputError = True

            'is a vehicle model entered
        ElseIf txtModel.TextLength < 1 Then
            MsgBox("Please enter a Vehicle Model", , "Error")
            txtModel.Clear()
            txtModel.Focus()
            InputError = True

            'check that year entered is numeric and then check if its between 1920 and 2100
        ElseIf IsNumeric(txtYear.Text) = False Then
            MsgBox("Please enter a Valid Year between 1920 and 2100", , "Error")
            txtYear.Clear()
            txtYear.Focus()
            InputError = True

        ElseIf Convert.ToInt32(txtYear.Text) < 1920 Or Convert.ToInt32(txtYear.Text) > 2100 Then
            MsgBox("Please enter a Valid Year between 1920 and 2100", , "Error")
            txtYear.Clear()
            txtYear.Focus()
            InputError = True



            'check that mileage is a valid number below 400,000
        ElseIf IsNumeric(txtMileage.Text) = False Then
            MsgBox("Please enter a valid number for Mileage", , "Error")
            txtMileage.Clear()
            txtMileage.Focus()
            InputError = True

        ElseIf Convert.ToInt32(txtMileage.Text) < 0 Or Convert.ToInt32(txtMileage.Text) > 400000 Then
            MsgBox("Please enter a valid number for Mileage", , "Error")
            txtMileage.Clear()
            txtMileage.Focus()
            InputError = True


            'check that price is a valid number below 100000
        ElseIf IsNumeric(txtPrice.Text) = False Then
            MsgBox("Please enter a valid Price", , "Error")
            txtPrice.Clear()
            txtPrice.Focus()
            InputError = True

        ElseIf Convert.ToInt32(txtPrice.Text) < 0 Or Convert.ToInt32(txtPrice.Text) > 100000 Then
            MsgBox("Please enter a valid Price", , "Error")
            txtPrice.Clear()
            txtPrice.Focus()
            InputError = True

            'check that color is selected
        ElseIf cboColor.SelectedIndex < 0 Then
            MsgBox("Please select a Color", , "Error")
            cboColor.Focus()
            InputError = True


        End If


        'if no input error then process the sticker price
        If Not InputError Then
            'if convertible is checked  calulate convertible price, if not set sticker price
            If chkConvertible.Checked Then
                objConvertible = New Convertible(txtVIN.Text, txtMake.Text, txtModel.Text, txtYear.Text, txtMileage.Text, txtPrice.Text, Convert.ToString(cboColor.SelectedItem))
                lblStickerPrice.Visible = True
                lblStickerPrice.Text = "Sticker price is: " & (objConvertible.ComputePrice()).ToString("C2")

            Else
                objStandard = New Standard(txtVIN.Text, txtMake.Text, txtModel.Text, txtYear.Text, txtMileage.Text, txtPrice.Text, Convert.ToString(cboColor.SelectedItem))

                lblStickerPrice.Visible = True
                lblStickerPrice.Text = "Sticker price is: " & (objStandard.ComputePrice()).ToString("C2")
            End If


        End If

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'this event handler clears input when the clear button is clicked, hides lblStickerPrice and puts focus on txtVIN

        txtVIN.Clear()
        txtMake.Clear()
        txtModel.Clear()
        txtYear.Clear()
        txtMileage.Clear()
        txtPrice.Clear()
        cboColor.SelectedIndex = -1
        chkConvertible.Checked = False
        lblStickerPrice.Text = ""
        lblStickerPrice.Visible = False
        txtVIN.Focus()

    End Sub

    Private Sub DisplayInventoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisplayInventoryToolStripMenuItem.Click
        'this event handler calls frmInventory and Hides miniCooper.vb
        Dim frmInventory As New frmInventory

        Hide()
        frmInventory.ShowDialog()



    End Sub
End Class
