﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMiniCooper
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mnuMiniCooper = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisplayInventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.picMini = New System.Windows.Forms.PictureBox()
        Me.lblMiniCooperCars = New System.Windows.Forms.Label()
        Me.lblVIN = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblMileage = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblColor = New System.Windows.Forms.Label()
        Me.lblStickerPrice = New System.Windows.Forms.Label()
        Me.txtVIN = New System.Windows.Forms.TextBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.txtMileage = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.cboColor = New System.Windows.Forms.ComboBox()
        Me.chkConvertible = New System.Windows.Forms.CheckBox()
        Me.btnStickerPrice = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtMake = New System.Windows.Forms.TextBox()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.mnuMiniCooper.SuspendLayout()
        CType(Me.picMini, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mnuMiniCooper
        '
        Me.mnuMiniCooper.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuMiniCooper.Location = New System.Drawing.Point(0, 0)
        Me.mnuMiniCooper.Name = "mnuMiniCooper"
        Me.mnuMiniCooper.Size = New System.Drawing.Size(887, 24)
        Me.mnuMiniCooper.TabIndex = 0
        Me.mnuMiniCooper.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisplayInventoryToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'DisplayInventoryToolStripMenuItem
        '
        Me.DisplayInventoryToolStripMenuItem.Name = "DisplayInventoryToolStripMenuItem"
        Me.DisplayInventoryToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.DisplayInventoryToolStripMenuItem.Text = "Display Inventory"
        '
        'picMini
        '
        Me.picMini.Image = Global.MiniCooper.My.Resources.Resources.mini
        Me.picMini.Location = New System.Drawing.Point(504, 112)
        Me.picMini.Name = "picMini"
        Me.picMini.Size = New System.Drawing.Size(371, 248)
        Me.picMini.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMini.TabIndex = 1
        Me.picMini.TabStop = False
        '
        'lblMiniCooperCars
        '
        Me.lblMiniCooperCars.AutoSize = True
        Me.lblMiniCooperCars.Font = New System.Drawing.Font("Imprint MT Shadow", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMiniCooperCars.Location = New System.Drawing.Point(241, 43)
        Me.lblMiniCooperCars.Name = "lblMiniCooperCars"
        Me.lblMiniCooperCars.Size = New System.Drawing.Size(405, 57)
        Me.lblMiniCooperCars.TabIndex = 0
        Me.lblMiniCooperCars.Text = "Mini Cooper Cars"
        '
        'lblVIN
        '
        Me.lblVIN.AutoSize = True
        Me.lblVIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVIN.Location = New System.Drawing.Point(12, 115)
        Me.lblVIN.Name = "lblVIN"
        Me.lblVIN.Size = New System.Drawing.Size(185, 25)
        Me.lblVIN.TabIndex = 0
        Me.lblVIN.Text = "Vehicle Number:"
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblModel.Location = New System.Drawing.Point(12, 207)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(168, 25)
        Me.lblModel.TabIndex = 0
        Me.lblModel.Text = "Vehicle Model:"
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYear.Location = New System.Drawing.Point(12, 253)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(69, 25)
        Me.lblYear.TabIndex = 0
        Me.lblYear.Text = "Year:"
        '
        'lblMileage
        '
        Me.lblMileage.AutoSize = True
        Me.lblMileage.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMileage.Location = New System.Drawing.Point(12, 299)
        Me.lblMileage.Name = "lblMileage"
        Me.lblMileage.Size = New System.Drawing.Size(102, 25)
        Me.lblMileage.TabIndex = 0
        Me.lblMileage.Text = "Mileage:"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.Location = New System.Drawing.Point(12, 345)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(73, 25)
        Me.lblPrice.TabIndex = 0
        Me.lblPrice.Text = "Price:"
        '
        'lblColor
        '
        Me.lblColor.AutoSize = True
        Me.lblColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblColor.Location = New System.Drawing.Point(12, 391)
        Me.lblColor.Name = "lblColor"
        Me.lblColor.Size = New System.Drawing.Size(75, 25)
        Me.lblColor.TabIndex = 0
        Me.lblColor.Text = "Color:"
        '
        'lblStickerPrice
        '
        Me.lblStickerPrice.AutoSize = True
        Me.lblStickerPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStickerPrice.Location = New System.Drawing.Point(235, 553)
        Me.lblStickerPrice.Name = "lblStickerPrice"
        Me.lblStickerPrice.Size = New System.Drawing.Size(417, 25)
        Me.lblStickerPrice.TabIndex = 0
        Me.lblStickerPrice.Text = "XXXXXXXXXXXXXXXXXXXXXXXXXXX"
        Me.lblStickerPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblStickerPrice.Visible = False
        '
        'txtVIN
        '
        Me.txtVIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtVIN.Location = New System.Drawing.Point(203, 112)
        Me.txtVIN.Name = "txtVIN"
        Me.txtVIN.Size = New System.Drawing.Size(221, 31)
        Me.txtVIN.TabIndex = 1
        '
        'txtModel
        '
        Me.txtModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtModel.Location = New System.Drawing.Point(203, 204)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(221, 31)
        Me.txtModel.TabIndex = 3
        '
        'txtYear
        '
        Me.txtYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtYear.Location = New System.Drawing.Point(203, 250)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(221, 31)
        Me.txtYear.TabIndex = 4
        '
        'txtMileage
        '
        Me.txtMileage.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtMileage.Location = New System.Drawing.Point(203, 296)
        Me.txtMileage.Name = "txtMileage"
        Me.txtMileage.Size = New System.Drawing.Size(221, 31)
        Me.txtMileage.TabIndex = 5
        '
        'txtPrice
        '
        Me.txtPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtPrice.Location = New System.Drawing.Point(203, 342)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(221, 31)
        Me.txtPrice.TabIndex = 6
        '
        'cboColor
        '
        Me.cboColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.cboColor.FormattingEnabled = True
        Me.cboColor.Items.AddRange(New Object() {"Black", "Dark Grey", "Red", "Regal Red", "Champagne Metallic", "Dusk Copper", "Racing Green", "Blue Metallic", "Coastal Blue", "Royal Blue", "Agave Green", "Lagoon Blue", "Rally Red", "Metallic Moonlight", "Black Cherry", "Meteor Gray", "Jaded Green"})
        Me.cboColor.Location = New System.Drawing.Point(203, 392)
        Me.cboColor.Name = "cboColor"
        Me.cboColor.Size = New System.Drawing.Size(221, 33)
        Me.cboColor.TabIndex = 7
        Me.cboColor.Text = "Choose a Color"
        '
        'chkConvertible
        '
        Me.chkConvertible.AutoSize = True
        Me.chkConvertible.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.chkConvertible.Location = New System.Drawing.Point(607, 394)
        Me.chkConvertible.Name = "chkConvertible"
        Me.chkConvertible.Size = New System.Drawing.Size(164, 29)
        Me.chkConvertible.TabIndex = 8
        Me.chkConvertible.Text = "Convertible?"
        Me.chkConvertible.UseVisualStyleBackColor = True
        '
        'btnStickerPrice
        '
        Me.btnStickerPrice.BackColor = System.Drawing.Color.Gray
        Me.btnStickerPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnStickerPrice.ForeColor = System.Drawing.Color.White
        Me.btnStickerPrice.Location = New System.Drawing.Point(240, 462)
        Me.btnStickerPrice.Name = "btnStickerPrice"
        Me.btnStickerPrice.Size = New System.Drawing.Size(167, 43)
        Me.btnStickerPrice.TabIndex = 9
        Me.btnStickerPrice.Text = "Sticker Price"
        Me.btnStickerPrice.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Gray
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.Location = New System.Drawing.Point(485, 462)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(167, 43)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'txtMake
        '
        Me.txtMake.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.txtMake.Location = New System.Drawing.Point(203, 158)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(221, 31)
        Me.txtMake.TabIndex = 2
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMake.Location = New System.Drawing.Point(12, 161)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(161, 25)
        Me.lblMake.TabIndex = 10
        Me.lblMake.Text = "Vehicle Make:"
        '
        'frmMiniCooper
        '
        Me.AcceptButton = Me.btnStickerPrice
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Yellow
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(887, 596)
        Me.Controls.Add(Me.txtMake)
        Me.Controls.Add(Me.lblMake)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnStickerPrice)
        Me.Controls.Add(Me.chkConvertible)
        Me.Controls.Add(Me.cboColor)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtMileage)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.txtModel)
        Me.Controls.Add(Me.txtVIN)
        Me.Controls.Add(Me.lblStickerPrice)
        Me.Controls.Add(Me.lblColor)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblMileage)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblVIN)
        Me.Controls.Add(Me.lblMiniCooperCars)
        Me.Controls.Add(Me.picMini)
        Me.Controls.Add(Me.mnuMiniCooper)
        Me.MainMenuStrip = Me.mnuMiniCooper
        Me.Name = "frmMiniCooper"
        Me.Text = "Mini Cooper Dealership"
        Me.mnuMiniCooper.ResumeLayout(False)
        Me.mnuMiniCooper.PerformLayout()
        CType(Me.picMini, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMiniCooper As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DisplayInventoryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents picMini As PictureBox
    Friend WithEvents lblMiniCooperCars As Label
    Friend WithEvents lblVIN As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblMileage As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblColor As Label
    Friend WithEvents lblStickerPrice As Label
    Friend WithEvents txtVIN As TextBox
    Friend WithEvents txtModel As TextBox
    Friend WithEvents txtYear As TextBox
    Friend WithEvents txtMileage As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents cboColor As ComboBox
    Friend WithEvents chkConvertible As CheckBox
    Friend WithEvents btnStickerPrice As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtMake As TextBox
    Friend WithEvents lblMake As Label
End Class
