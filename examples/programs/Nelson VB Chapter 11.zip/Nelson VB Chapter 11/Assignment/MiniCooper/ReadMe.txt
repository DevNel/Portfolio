I went ahead and included my text file for this program. It should be placed in the root of D:. I used that
location because it seems to be what the book does.