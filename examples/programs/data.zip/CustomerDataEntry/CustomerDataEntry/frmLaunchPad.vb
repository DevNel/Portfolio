﻿Public Class frmLaunchPad
    Private Sub BtnCustomerEntry_Click(sender As Object, e As EventArgs) Handles btnCustomerEntry.Click
        'Shows an instance of the Customer Data Entry Form
        frmCustomerData.Show()
    End Sub

    Private Sub BtnInventory_Click(sender As Object, e As EventArgs) Handles btnInventory.Click
        'Shows an instance of the Inventory Form
        frmInventory.Show()
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Exits Launchpad
        Close()
    End Sub
End Class