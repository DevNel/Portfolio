﻿Public Class frmCustomerData
    Private Sub FrmCustomerData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'WidgetWorldDataSet1.dbo_CustomerInfo' table. You can move, or remove it, as needed.
        Me.Dbo_CustomerInfoTableAdapter.Fill(Me.WidgetWorldDataSet1.dbo_CustomerInfo)



    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        'this button is sized 0, 0 because hiding it made this section of code fail to execute
        'TODO: Move this code to its own subroutine

        'declare variables
        Dim strErrorMessage = ""
        Dim blnValidEntry = True


        'check first name
        If txtFirstName.TextLength < 3 Then

            strErrorMessage += "Please enter a first name longer than three letters" & vbNewLine
            txtFirstName.Focus()
            txtFirstName.Clear()
            'set error flag
            blnValidEntry = False

        End If

        'check last name
        If txtLastName.TextLength < 3 Then
            strErrorMessage += "Please enter a last name longer than three letters" & vbNewLine
            txtLastName.Focus()
            txtLastName.Clear()
            'set error flag
            blnValidEntry = False

        End If

        'check that street address data exists
        If txtStreet1.TextLength < 1 Then
            strErrorMessage += "Please enter a street address" & vbNewLine
            txtStreet1.Focus()
            txtStreet1.Clear()
            'set error flag
            blnValidEntry = False

        End If

        'check that city data exists
        If txtCity.TextLength < 1 Then
            strErrorMessage += "Please enter a city" & vbNewLine
            txtCity.Focus()
            txtCity.Clear()
            'set error flag
            blnValidEntry = False

        End If

        'check state selection
        If cboState.SelectedIndex = -1 Then
            strErrorMessage += "Please select a state" & vbNewLine
            cboState.Focus()
            'set error flag
            blnValidEntry = False
        End If

        'check zip code
        If txtZip.TextLength <> 5 Then
            strErrorMessage += "ZIP codes should contain five numbers" & vbNewLine
            txtZip.Focus()
            txtZip.Clear()
            'set error flag
            blnValidEntry = False

        Else
            'check for numeric value
            If Int32.TryParse(txtZip.Text, 5) Then

            Else
                strErrorMessage += "ZIP Code should contain numeric data" & vbNewLine
                txtZip.Focus()
                txtZip.Clear()
                'set error flag
                blnValidEntry = False
            End If

        End If


        'check phone number
        If txtPhone.TextLength <> 10 Then
            strErrorMessage += "Phone numbers should contain ten digits" & vbNewLine
            txtPhone.Focus()
            txtPhone.Clear()
            'set error flag
            blnValidEntry = False

        Else
            'check for numeric value
            If Int64.TryParse(txtPhone.Text, 10) Then

            Else
                strErrorMessage += "Phone number should contain numeric data" & vbNewLine

                txtPhone.Focus()
                txtPhone.Clear()
                'set error flag
                blnValidEntry = False
            End If

        End If

        'check email
        If txtEmail.TextLength < 1 Then
            strErrorMessage += "Please enter a valid email address" & vbNewLine
            txtEmail.Focus()
            txtEmail.Clear()
            'set error flag
            blnValidEntry = False


        Else
            'looks for an @ symbol
            If txtEmail.Text.Contains("@") Then

            Else
                strErrorMessage += "Please enter a valid email address" & vbNewLine
                txtEmail.Focus()
                txtEmail.Clear()
                'set error flag
                blnValidEntry = False

            End If
        End If

        'check if ValidEntry flag has been tripped
        If blnValidEntry = True Then

            'Dont clear
            ' btnClear.PerformClick()

        Else

            'display error message
            MsgBox(strErrorMessage, , "Invalid Input")

        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'set focus clear everything and set combobox
        txtFirstName.Focus()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtStreet1.Clear()
        txtStreet2.Clear()
        txtCity.Clear()
        txtZip.Clear()
        txtPhone.Clear()
        txtEmail.Clear()
        cboState.SelectedIndex = -1

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'exit app
        Close()

    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click


        'displays confirmation box to confirm deletion
        If MessageBox.Show("Are you sure you want to delete this record (This cannot be undone)?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then 'displays confirmation dialog

            Try
                Me.Validate() 'generic validation
                Me.Dbo_CustomerInfoBindingSource.RemoveCurrent()
                Me.Dbo_CustomerInfoBindingSource.EndEdit()
                Me.Dbo_CustomerInfoTableAdapter.Update(Me.WidgetWorldDataSet1.dbo_CustomerInfo)

                'shows confirmation message
                MessageBox.Show("Record Deleted.")

            Catch ex As Exception
                MessageBox.Show("Unable to Delete.")
            End Try


        End If

    End Sub

    Private Sub tsSave_Click(sender As Object, e As EventArgs) Handles tsSave.Click
        Try
            Me.Validate() ' generic validation
            Me.Dbo_CustomerInfoBindingSource.EndEdit()

            'run the validation code
            Me.btnEnter.PerformClick()

            Me.Dbo_CustomerInfoTableAdapter.Update(Me.WidgetWorldDataSet1.dbo_CustomerInfo)
            Me.Dbo_CustomerInfoBindingSource.ResumeBinding()

            'shows confirmation message
            MessageBox.Show("Record Saved.")

        Catch ex As Exception
            MessageBox.Show("Cannot Save")
        End Try

    End Sub



End Class
