﻿Public Class frmInventory


    Private Sub FrmInventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'WidgetWorldDataSet1.dbo_Inventory' table. You can move, or remove it, as needed.
        Me.Dbo_InventoryTableAdapter.Fill(Me.WidgetWorldDataSet1.dbo_Inventory)

    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'save changes made to the database
        Me.Dbo_InventoryTableAdapter.Update(Me.WidgetWorldDataSet1.dbo_Inventory)
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'close instance
        Close()
    End Sub




End Class