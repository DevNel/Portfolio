﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmApartmentRental
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.mnuStrip = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDisplayTopTen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.picRental = New System.Windows.Forms.PictureBox()
        Me.lstCitySelect = New System.Windows.Forms.ListBox()
        Me.lblCitySelect = New System.Windows.Forms.Label()
        Me.lblMedianCost = New System.Windows.Forms.Label()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.lblAverageCityCost = New System.Windows.Forms.Label()
        Me.mnuStrip.SuspendLayout()
        CType(Me.picRental, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Georgia", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.Sienna
        Me.lblTitle.Location = New System.Drawing.Point(56, 25)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(689, 38)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Two-Bedroom Median Apartment Rental"
        '
        'mnuStrip
        '
        Me.mnuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuStrip.Location = New System.Drawing.Point(0, 0)
        Me.mnuStrip.Name = "mnuStrip"
        Me.mnuStrip.Size = New System.Drawing.Size(800, 24)
        Me.mnuStrip.TabIndex = 1
        Me.mnuStrip.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDisplayTopTen, Me.mnuClear, Me.mnuExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'mnuDisplayTopTen
        '
        Me.mnuDisplayTopTen.Name = "mnuDisplayTopTen"
        Me.mnuDisplayTopTen.Size = New System.Drawing.Size(278, 22)
        Me.mnuDisplayTopTen.Text = "Display Top Ten Cities and Rental Costs"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(278, 22)
        Me.mnuClear.Text = "Clear"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(278, 22)
        Me.mnuExit.Text = "Exit"
        '
        'picRental
        '
        Me.picRental.Image = Global.ApartmentRental.My.Resources.Resources.rental
        Me.picRental.Location = New System.Drawing.Point(113, 87)
        Me.picRental.Name = "picRental"
        Me.picRental.Size = New System.Drawing.Size(244, 238)
        Me.picRental.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRental.TabIndex = 2
        Me.picRental.TabStop = False
        '
        'lstCitySelect
        '
        Me.lstCitySelect.FormattingEnabled = True
        Me.lstCitySelect.Location = New System.Drawing.Point(444, 100)
        Me.lstCitySelect.Name = "lstCitySelect"
        Me.lstCitySelect.Size = New System.Drawing.Size(244, 225)
        Me.lstCitySelect.TabIndex = 3
        '
        'lblCitySelect
        '
        Me.lblCitySelect.AutoSize = True
        Me.lblCitySelect.Location = New System.Drawing.Point(441, 84)
        Me.lblCitySelect.Name = "lblCitySelect"
        Me.lblCitySelect.Size = New System.Drawing.Size(57, 13)
        Me.lblCitySelect.TabIndex = 4
        Me.lblCitySelect.Text = "Select City"
        '
        'lblMedianCost
        '
        Me.lblMedianCost.AutoSize = True
        Me.lblMedianCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMedianCost.Location = New System.Drawing.Point(185, 345)
        Me.lblMedianCost.Name = "lblMedianCost"
        Me.lblMedianCost.Size = New System.Drawing.Size(431, 16)
        Me.lblMedianCost.TabIndex = 5
        Me.lblMedianCost.Text = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        Me.lblMedianCost.Visible = False
        '
        'btnCompute
        '
        Me.btnCompute.BackColor = System.Drawing.Color.Sienna
        Me.btnCompute.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCompute.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompute.ForeColor = System.Drawing.Color.White
        Me.btnCompute.Location = New System.Drawing.Point(294, 374)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(212, 36)
        Me.btnCompute.TabIndex = 6
        Me.btnCompute.Text = "Compute Average Rental"
        Me.btnCompute.UseVisualStyleBackColor = False
        '
        'lblAverageCityCost
        '
        Me.lblAverageCityCost.AutoSize = True
        Me.lblAverageCityCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageCityCost.Location = New System.Drawing.Point(257, 425)
        Me.lblAverageCityCost.Name = "lblAverageCityCost"
        Me.lblAverageCityCost.Size = New System.Drawing.Size(287, 16)
        Me.lblAverageCityCost.TabIndex = 7
        Me.lblAverageCityCost.Text = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        Me.lblAverageCityCost.Visible = False
        '
        'frmApartmentRental
        '
        Me.AcceptButton = Me.btnCompute
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblAverageCityCost)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.lblMedianCost)
        Me.Controls.Add(Me.lblCitySelect)
        Me.Controls.Add(Me.lstCitySelect)
        Me.Controls.Add(Me.picRental)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.mnuStrip)
        Me.MainMenuStrip = Me.mnuStrip
        Me.Name = "frmApartmentRental"
        Me.Text = "Form1"
        Me.mnuStrip.ResumeLayout(False)
        Me.mnuStrip.PerformLayout()
        CType(Me.picRental, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents mnuStrip As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuDisplayTopTen As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents picRental As PictureBox
    Friend WithEvents lstCitySelect As ListBox
    Friend WithEvents lblCitySelect As Label
    Friend WithEvents lblMedianCost As Label
    Friend WithEvents btnCompute As Button
    Friend WithEvents lblAverageCityCost As Label
End Class
