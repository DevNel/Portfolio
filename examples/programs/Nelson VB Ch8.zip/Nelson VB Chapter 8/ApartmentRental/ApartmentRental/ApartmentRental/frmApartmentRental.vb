﻿'Program Name:  Apartment Rental by City
'Author:        Devon Nelson
'Date:          November 28. 2019
'Purpose:       This windows application uses a text file of median rental costs for a two-bedroom apartment in 10 major cities to find 
'               the average rental cost. The user can Select a city To display the median rental cost For that city.

Option Strict On


Public Class frmApartmentRental

    'class level variables

    Public Shared _intSizeofArray As Integer = 10
    Public Shared _strCityListing(_intSizeofArray) As String
    Public Shared _intCityMedian(_intSizeofArray) As Integer


    Private strMedianLabel As String = "The selected city rental's median cost of "
    Private strAverageLabel As String = "Average Rental City Cost "
    Private strSelectCityError As String = "Please select a city from the list"
    Private strMissingSelection As String = "Error - Missing Selection"

    'dummy string'
    Public Shared _strCityMedian(_intSizeofArray) As String

    Private Sub FrmApartmentRental_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'initialize an instance of streamreader object and declare variables

        Dim objReader As IO.StreamReader
        Dim strLocationAndNameOfFile As String = "d:\Desktop\Programming\Nelson VB Chapter 8\ApartmentRental\StudentDataFiles\rentals.txt"
        Dim intCount As Integer = 0
        Dim intFill As Integer
        Dim strFileError As String = "The file is not available. Restart when the file is available."



        'Check that inventory file exists.

        If IO.File.Exists(strLocationAndNameOfFile) Then
            objReader = IO.File.OpenText(strLocationAndNameOfFile)

            'read the file until the file is completed
            Do While objReader.Peek <> -1

                _strCityListing(intCount) = objReader.ReadLine()

                'for some reason this peice of code doesnt work here even though it does in the example project. replacing it with a dumby array to finish before troubleshooting'
                '  _intCityMedian(intCount) = Convert.ToInt32(objReader.ReadLine())
                _strCityMedian(intCount) = objReader.ReadLine()

                intCount += 1

            Loop

            'dumby array'
            _intCityMedian = {4570, 4310, 3200, 3200, 3000, 2600, 2580, 2450, 2400, 2210}
            ''

            objReader.Close()

            'the ListBox object is filled with CityListings

            For intFill = 0 To (_strCityListing.Length - 1)
                lstCitySelect.Items.Add(_strCityListing(intFill))
            Next

        Else
            MsgBox(strFileError, , "Error")
            Close()

        End If

    End Sub

    Private Sub LstCitySelect_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstCitySelect.SelectedIndexChanged
        'this sub pulls the currently selected cities median from the array _intCityMedian when a selection is made in the lstCity select item.
        'it then updates the label and makes it visible.

        'declare variable for integer
        Dim intSelectedCityMedian As Integer


        If lstCitySelect.SelectedIndex >= 0 Then
            intSelectedCityMedian = _intCityMedian(lstCitySelect.SelectedIndex)

        Else
            MsgBox(strSelectCityError, , strMissingSelection)

        End If


        lblMedianCost.Visible = True
        lblMedianCost.Text = strMedianLabel & intSelectedCityMedian.ToString("C0")

    End Sub

    Private Sub BtnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click



        ' when the btnCompute is clicked lstCitySelect is checked for a selection, if true another sub is called to calculate the average rental the laberl is changed

        Dim decAverageCityRent As Decimal



        If lstCitySelect.SelectedIndex >= 0 Then
            CalcAverageCity(decAverageCityRent)

            lblAverageCityCost.Text = strAverageLabel & decAverageCityRent.ToString("c0")
            lblAverageCityCost.Visible = True

        Else

        End If

    End Sub

    Private Sub CalcAverageCity(ByRef decAverageCityRent As Decimal)


        Dim intAdd As Integer
        Dim intTotal As Integer
        Dim intNumberofCities As Integer

        intNumberofCities = _intCityMedian.Length

        For intAdd = 0 To (_intCityMedian.Length - 1)
            intTotal += _intCityMedian(intAdd)

        Next

        decAverageCityRent = Convert.ToDecimal(intTotal / intNumberofCities)





    End Sub

    Private Sub MnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click

        lstCitySelect.SelectedIndex = 0
        lblAverageCityCost.Text = ""
        lblAverageCityCost.Visible = False
        lblMedianCost.Text = ""
        lblMedianCost.Visible = False


    End Sub

    Private Sub MnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'this menu event exits the application
        Application.Exit()

    End Sub

    Private Sub MnuDisplayTopTen_Click(sender As Object, e As EventArgs) Handles mnuDisplayTopTen.Click
        'the mnuDisplay click event creates an instance of the frmCityList
        Dim frmSecond As New frmCityList

        'hide this form and show the display city list form
        Hide()
        frmSecond.ShowDialog()
    End Sub
End Class
