﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCityList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstCityNames = New System.Windows.Forms.ListBox()
        Me.lstCityCosts = New System.Windows.Forms.ListBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstCityNames
        '
        Me.lstCityNames.FormattingEnabled = True
        Me.lstCityNames.Location = New System.Drawing.Point(71, 42)
        Me.lstCityNames.Name = "lstCityNames"
        Me.lstCityNames.Size = New System.Drawing.Size(283, 277)
        Me.lstCityNames.TabIndex = 0
        '
        'lstCityCosts
        '
        Me.lstCityCosts.FormattingEnabled = True
        Me.lstCityCosts.Location = New System.Drawing.Point(446, 42)
        Me.lstCityCosts.Name = "lstCityCosts"
        Me.lstCityCosts.Size = New System.Drawing.Size(283, 277)
        Me.lstCityCosts.TabIndex = 1
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.Sienna
        Me.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReturn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.Color.White
        Me.btnReturn.Location = New System.Drawing.Point(308, 357)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(184, 56)
        Me.btnReturn.TabIndex = 2
        Me.btnReturn.Text = "Return to Rental Cities"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'frmCityList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.lstCityCosts)
        Me.Controls.Add(Me.lstCityNames)
        Me.Name = "frmCityList"
        Me.Text = "City Rentals"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lstCityNames As ListBox
    Friend WithEvents lstCityCosts As ListBox
    Friend WithEvents btnReturn As Button
End Class
