﻿'The frmCityList Class Is opened by frmApartmentRental And displays the inventory file In sorted order

Option Strict On

Public Class frmCityList
    Private Sub FrmCityList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For intFill = 0 To (frmApartmentRental._strCityListing.Length - 1)
            lstCityNames.Items.Add(frmApartmentRental._strCityListing(intFill))
        Next

        For intFill = 0 To (frmApartmentRental._strCityMedian.Length - 1)
            lstCityCosts.Items.Add(frmApartmentRental._strCityMedian(intFill))
        Next
    End Sub
End Class