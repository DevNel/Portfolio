﻿' The frmDIsplayInventory class is opened by frmDepreciation and displays the inventory file in sorted order

Option Strict On


Public Class frmDisplayInventory
    Private Sub FrmDisplayInventory_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'the frmDisplayInventory load event is a second forms that displays the sorted inventory items

        Dim strItem As String

        ' sorts the _strInventoryItem array
        Array.Sort(frmDeprication._strInventoryItem)

        'Displays the _strInventoryItem array
        For Each strItem In frmDeprication._strInventoryItem
            lstDisplay.Items.Add(strItem)
        Next

    End Sub

    Private Sub BtnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        ' this sub procedure opens the first form
        Dim frmFirst As New frmDeprication

        Hide()
        frmFirst.ShowDialog()

    End Sub
End Class