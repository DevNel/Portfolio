﻿'   Program Name:   Decking Cost Calculator Application
'   Author:         Devon Nelson
'   Date:           October 17, 2019
'   Purpose:        This Windows application computes the estimated cost of decking based on the
'                   number of square feet and the following cost per square foot: Lumber - $2.35 per square foot;
'                   Redwood - $7.75 per square foot; Composite - $8.50 per square foot.

Option Strict On

Public Class frmDecking
    Private Sub TxtFootage_TextChanged(sender As Object, e As EventArgs) Handles txtFootage.TextChanged

    End Sub

    Private Sub LblSquareFeet_Click(sender As Object, e As EventArgs) Handles lblSquareFeet.Click

    End Sub

    Private Sub FrmDecking_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'This even handler is executed when the form is loaded. It sets the focus to txtFootage and clears lblCostEstimate

        txtFootage.Focus()
        lblCostEstimate.Text = ""
    End Sub

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        '   The btnCalculate event handler calculates the estimated cost of decking
        '   based on the square footage and the decking type

        '   Declarations
        Dim decFootage As Decimal
        Dim decCostPerSquareFoot As Decimal
        Dim decCostEstimate As Decimal
        Dim decLumberCost As Decimal = 2.35D
        Dim decRedwoodCost As Decimal = 7.75D
        Dim decCompositeCost As Decimal = 8.5D

        'check for numeric value in txtFootage and if yes convert to decimal

        If IsNumeric(txtFootage.Text) Then
            decFootage = Convert.ToDecimal(txtFootage.Text)

            'check that decFootage is greater than 0
            If decFootage > 0 Then

                'check if radLumber is checked
                If radLumber.Checked Then

                    'if yes sets decCostPerSquare foot to decLumberCost
                    decCostPerSquareFoot = decLumberCost

                    'Else check if radRedwood is checked
                ElseIf radRedwood.Checked Then

                    'if yes set decCostPerSquarefoot to decRedwoodCost
                    decCostPerSquareFoot = decRedwoodCost

                    'Else check if radComposite is checked
                ElseIf radComposite.Checked Then

                    'if yes set decCostPerSquarefoot to decCompositeCost
                    decCostPerSquareFoot = decCompositeCost
                End If

                'calculate and display estimate
                decCostEstimate = decFootage * decCostPerSquareFoot
                lblCostEstimate.Text = decCostEstimate.ToString("C")

            Else

                ' Display error if the user entered a negative value, reset txtFootage and refocus
                MsgBox("You Entered " & decFootage.ToString() & ". Enter a Positive Number", , "Input Error")
                txtFootage.Text = ""
                txtFootage.Focus()

            End If

        Else

            ' Display error message if user entered a nonnumeric value
            MsgBox("Enter the Square Footage of Decking", , "Input Error")
            txtFootage.Text = ""
            txtFootage.Focus()

        End If
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'This event handler is executed when btnClear is clicked. It clears txtFootage and lblCostEstimate, resets the radio buttons
        'and sets focus to txtFootage

        txtFootage.Clear()
        lblCostEstimate.Text = ""
        radLumber.Checked = True
        radRedwood.Checked = False
        radComposite.Checked = False
        txtFootage.Focus()

    End Sub
End Class
